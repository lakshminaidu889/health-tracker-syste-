// Initialize variables
let steps = 0;
let calories = 0;
let water = 0;

// Step Tracker
function addSteps(count) {
  steps += count;
  document.getElementById("steps").textContent = steps;
}

function resetSteps() {
  steps = 0;
  document.getElementById("steps").textContent = steps;
}

// Calorie Tracker
function addCalories() {
  const input = document.getElementById("calInput").value;
  if (input && input > 0) {
    calories += parseInt(input);
    document.getElementById("calories").textContent = calories;
    document.getElementById("calInput").value = "";
  } else {
    alert("Please enter a valid calorie value");
  }
}

function resetCalories() {
  calories = 0;
  document.getElementById("calories").textContent = calories;
}

// Water Tracker
function addWater(amount) {
  water += amount;
  document.getElementById("water").textContent = water.toFixed(2);
}

function resetWater() {
  water = 0;
  document.getElementById("water").textContent = water.toFixed(2);
}
